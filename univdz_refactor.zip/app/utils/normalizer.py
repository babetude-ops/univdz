import re
from datetime import datetime
from slugify import slugify

TYPE_KEYWORDS = {
    "colloque": ["colloque", "congrès"],
    "séminaire": ["séminaire", "seminar"],
    "journée_etude": ["journée d'étude", "journées d'étude"],
    "appel_communication": ["appel à communication", "appel à contribution", "call for paper"],
    "bourse": ["bourse", "scholarship", "fellowship", "erasmus", "mobilité"],
    "atelier": ["atelier", "workshop"],
    "conférence": ["conférence", "conference"],
    "doctorat": ["doctorat", "phd", "thèse"],
}

DISCIPLINE_KEYWORDS = {
    "Informatique": ["informatique", "ia ", "intelligence artificielle", "data", "numérique"],
    "Mathématiques": ["mathématique", "algèbre", "analyse"],
    "Physique": ["physique", "énergie", "optique"],
    "Chimie": ["chimie", "biochimie"],
    "Sciences médicales": ["médecine", "santé", "pharmacie"],
    "Sciences de la nature": ["biologie", "écologie", "environnement"],
    "Droit": ["droit", "juridique"],
    "Économie": ["économie", "finance", "gestion", "management"],
    "Sciences humaines": ["histoire", "philosophie"],
    "Sciences sociales": ["sociologie", "psychologie"],
    "Lettres et langues": ["littérature", "linguistique", "langue"],
    "Architecture": ["architecture", "urbanisme"],
    "Ingénierie": ["génie", "mécanique", "électronique"],
    "Sciences agronomiques": ["agronomie", "agriculture", "vétérinaire"],
}


def detect_type(titre, description=""):
    text = (titre + " " + (description or "")).lower()
    for event_type, keywords in TYPE_KEYWORDS.items():
        if any(kw in text for kw in keywords):
            return event_type
    return "autre"


def detect_discipline(titre, description=""):
    text = (titre + " " + (description or "")).lower()
    for discipline, keywords in DISCIPLINE_KEYWORDS.items():
        if any(kw in text for kw in keywords):
            return discipline
    return "Autre"


def compute_score(data):
    score = 0.3
    if data.get("lien_officiel"): score += 0.2
    if data.get("date_debut"): score += 0.2
    if data.get("description") and len(data["description"]) > 50: score += 0.15
    if data.get("institution"): score += 0.1
    if data.get("wilaya"): score += 0.05
    return min(round(score, 2), 1.0)


def normalize_opportunity(raw, source=""):
    """Normalise un dictionnaire brut en Opportunity."""
    titre = (raw.get("titre") or "").strip()
    description = (raw.get("description") or "").strip()

    # Compatibilité avec ancien champ "universite"
    institution = raw.get("institution") or raw.get("universite") or ""

    event_type = raw.get("type") or detect_type(titre, description)
    discipline = raw.get("discipline") or detect_discipline(titre, description)

    normalized = {
        "titre": titre[:500],
        "type": event_type,
        "categorie": raw.get("categorie", ""),
        "institution": institution.strip()[:300],
        "wilaya": (raw.get("wilaya") or "").strip()[:100],
        "pays": (raw.get("pays") or "Algérie").strip()[:100],
        "discipline": discipline,
        "sous_discipline": (raw.get("sous_discipline") or "").strip()[:200],
        "date_debut": raw.get("date_debut"),
        "date_fin": raw.get("date_fin"),
        "date_limite": raw.get("date_limite"),
        "description": description,
        "lien_officiel": (raw.get("lien_officiel") or "").strip()[:1000],
        "source_nom": (source or raw.get("source_nom") or raw.get("source") or "")[:500],
        "source_url": (raw.get("source_url") or "").strip()[:1000],
        "date_collecte": datetime.utcnow(),
        "statut": "a_verifier",
    }
    normalized["score_fiabilite"] = compute_score(normalized)
    return normalized


# Alias pour compatibilité avec ancien code
def normalize_event(raw, source=""):
    return normalize_opportunity(raw, source)


def generate_slug(titre, date_debut=None):
    base = slugify(titre[:80], allow_unicode=False, separator="-")
    if date_debut:
        suffix = str(date_debut).replace("-", "")[:8]
        base = f"{base}-{suffix}"
    from app.models.event import Opportunity
    slug = base
    counter = 1
    while Opportunity.query.filter_by(slug=slug).first():
        slug = f"{base}-{counter}"
        counter += 1
    return slug
