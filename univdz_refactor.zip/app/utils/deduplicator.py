from app.models.event import Opportunity


def is_duplicate(data: dict) -> bool:
    """Vérifie si une opportunité existe déjà en base."""

    # 1. Par lien officiel
    if data.get("lien_officiel"):
        if Opportunity.query.filter_by(lien_officiel=data["lien_officiel"]).first():
            return True

    # 2. Par titre + source
    if data.get("titre") and data.get("source_nom"):
        if Opportunity.query.filter_by(
            titre=data["titre"],
            source_nom=data["source_nom"]
        ).first():
            return True

    return False
