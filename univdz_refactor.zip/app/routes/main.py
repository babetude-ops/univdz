from flask import Blueprint, render_template, request
from app.models.event import Opportunity, Revue
from app import db
from sqlalchemy import or_

main_bp = Blueprint("main", __name__)

OPPS_PER_PAGE = 12

WILAYAS = [
    "Adrar", "Chlef", "Laghouat", "Oum El Bouaghi", "Batna", "Béjaïa", "Biskra",
    "Béchar", "Blida", "Bouira", "Tamanrasset", "Tébessa", "Tlemcen", "Tiaret",
    "Tizi Ouzou", "Alger", "Djelfa", "Jijel", "Sétif", "Saïda", "Skikda",
    "Sidi Bel Abbès", "Annaba", "Guelma", "Constantine", "Médéa", "Mostaganem",
    "M'Sila", "Mascara", "Ouargla", "Oran", "El Bayadh", "Illizi", "Bordj Bou Arréridj",
    "Boumerdès", "El Tarf", "Tindouf", "Tissemsilt", "El Oued", "Khenchela",
    "Souk Ahras", "Tipaza", "Mila", "Aïn Defla", "Naâma", "Aïn Témouchent",
    "Ghardaïa", "Relizane", "Timimoun", "Bordj Badji Mokhtar", "Ouled Djellal",
    "Béni Abbès", "In Salah", "In Guezzam", "Touggourt", "Djanet", "El M'Ghair", "El Meniaa",
]

OPP_TYPES = [
    "bourse", "colloque", "séminaire", "journée_etude",
    "appel_communication", "atelier", "conférence", "doctorat", "autre"
]

DISCIPLINES = [
    "Informatique", "Mathématiques", "Physique", "Chimie",
    "Sciences médicales", "Sciences de la nature", "Droit", "Économie",
    "Sciences humaines", "Sciences sociales", "Lettres et langues",
    "Architecture", "Ingénierie", "Sciences agronomiques", "Autre",
]


@main_bp.route("/")
def index():
    upcoming = (
        Opportunity.query.filter_by(statut="valide")
        .order_by(Opportunity.date_debut.asc())
        .limit(6)
        .all()
    )
    bourses = (
        Opportunity.query.filter_by(statut="valide", type="bourse")
        .order_by(Opportunity.date_limite.asc())
        .limit(4)
        .all()
    )
    stats = {
        "total": Opportunity.query.filter_by(statut="valide").count(),
        "bourses": Opportunity.query.filter_by(statut="valide", type="bourse").count(),
        "colloques": Opportunity.query.filter_by(statut="valide", type="colloque").count(),
    }
    return render_template(
        "main/index.html",
        upcoming=upcoming,
        bourses=bourses,
        stats=stats,
        wilayas=WILAYAS,
        event_types=OPP_TYPES,
        disciplines=DISCIPLINES,
    )


@main_bp.route("/opportunites")
def opportunites():
    page = request.args.get("page", 1, type=int)
    q = request.args.get("q", "")
    type_filtre = request.args.get("type", "")
    wilaya_filtre = request.args.get("wilaya", "")
    discipline_filtre = request.args.get("discipline", "")
    date_debut_filtre = request.args.get("date_debut", "")

    query = Opportunity.query.filter_by(statut="valide")

    if q:
        query = query.filter(
            or_(
                Opportunity.titre.ilike(f"%{q}%"),
                Opportunity.description.ilike(f"%{q}%"),
                Opportunity.institution.ilike(f"%{q}%"),
            )
        )
    if type_filtre:
        query = query.filter_by(type=type_filtre)
    if wilaya_filtre:
        query = query.filter_by(wilaya=wilaya_filtre)
    if discipline_filtre:
        query = query.filter_by(discipline=discipline_filtre)
    if date_debut_filtre:
        from datetime import datetime
        try:
            d = datetime.strptime(date_debut_filtre, "%Y-%m-%d").date()
            query = query.filter(Opportunity.date_debut >= d)
        except ValueError:
            pass

    pagination = query.order_by(Opportunity.date_debut.asc()).paginate(
        page=page, per_page=OPPS_PER_PAGE, error_out=False
    )

    return render_template(
        "main/evenements.html",
        events=pagination.items,
        pagination=pagination,
        wilayas=WILAYAS,
        event_types=OPP_TYPES,
        disciplines=DISCIPLINES,
        current_filters={
            "q": q,
            "type": type_filtre,
            "wilaya": wilaya_filtre,
            "discipline": discipline_filtre,
            "date_debut": date_debut_filtre,
        },
    )


# Alias pour compatibilité avec ancien URL /evenements
@main_bp.route("/evenements")
def evenements():
    return opportunites()


@main_bp.route("/opportunite/<slug>")
def detail(slug):
    opp = Opportunity.query.filter_by(slug=slug, statut="valide").first_or_404()
    similaires = (
        Opportunity.query.filter(
            Opportunity.statut == "valide",
            Opportunity.type == opp.type,
            Opportunity.id != opp.id,
        )
        .limit(3)
        .all()
    )
    return render_template("main/detail.html", event=opp, similaires=similaires)


# Alias pour ancien URL /evenement/<slug>
@main_bp.route("/evenement/<slug>")
def detail_old(slug):
    return detail(slug)


@main_bp.route("/bourses")
def bourses():
    bourses_list = (
        Opportunity.query.filter_by(statut="valide", type="bourse")
        .order_by(Opportunity.date_limite.asc())
        .all()
    )
    return render_template("main/bourses.html", bourses=bourses_list)


@main_bp.route("/revues")
def revues():
    domaine_filtre = request.args.get("domaine", "")
    query = Revue.query.filter_by(statut="valide")
    if domaine_filtre:
        query = query.filter_by(domaine=domaine_filtre)
    revues_list = query.order_by(Revue.date_collecte.desc()).all()

    domaines = {}
    for r in revues_list:
        d = r.domaine or "Autre"
        if d not in domaines:
            domaines[d] = []
        domaines[d].append(r)

    tous_domaines = Revue.query.filter_by(statut="valide").with_entities(Revue.domaine).distinct().all()
    tous_domaines = [d[0] for d in tous_domaines if d[0]]

    return render_template(
        "main/revues.html",
        domaines=domaines,
        tous_domaines=tous_domaines,
        domaine_filtre=domaine_filtre,
        total=len(revues_list),
    )


@main_bp.route("/revue/<slug>")
def detail_revue(slug):
    revue = Revue.query.filter_by(slug=slug, statut="valide").first_or_404()
    similaires = Revue.query.filter(
        Revue.statut == "valide",
        Revue.domaine == revue.domaine,
        Revue.id != revue.id,
    ).limit(4).all()
    return render_template("main/detail_revue.html", revue=revue, similaires=similaires)


@main_bp.route("/sitemap.xml")
def sitemap():
    from flask import make_response
    opps = Opportunity.query.filter_by(statut="valide").all()
    xml = render_template("main/sitemap.xml", events=opps)
    response = make_response(xml)
    response.headers["Content-Type"] = "application/xml"
    return response
