from flask import Blueprint, jsonify, request
from app.models.event import Opportunity, Revue

api_bp = Blueprint("api", __name__)


@api_bp.route("/opportunities")
def get_opportunities():
    type_filtre = request.args.get("type", "")
    wilaya_filtre = request.args.get("wilaya", "")
    limit = request.args.get("limit", 50, type=int)

    query = Opportunity.query.filter_by(statut="valide")
    if type_filtre:
        query = query.filter_by(type=type_filtre)
    if wilaya_filtre:
        query = query.filter_by(wilaya=wilaya_filtre)

    items = query.order_by(Opportunity.date_collecte.desc()).limit(limit).all()
    return jsonify([o.to_dict() for o in items])


# Alias pour compatibilité
@api_bp.route("/events")
def get_events():
    return get_opportunities()


@api_bp.route("/revues")
def get_revues():
    limit = request.args.get("limit", 50, type=int)
    items = Revue.query.filter_by(statut="valide").order_by(Revue.date_collecte.desc()).limit(limit).all()
    return jsonify([r.to_dict() for r in items])
