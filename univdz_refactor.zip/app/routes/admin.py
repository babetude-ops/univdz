from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user
from datetime import datetime
from app.models.event import Admin, Opportunity, Revue
from app import db

admin_bp = Blueprint("admin", __name__)


@admin_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("admin.dashboard"))
    if request.method == "POST":
        user = Admin.query.filter_by(username=request.form.get("username")).first()
        if user and user.check_password(request.form.get("password")):
            login_user(user, remember=True)
            return redirect(url_for("admin.dashboard"))
        flash("Identifiants incorrects.", "danger")
    return render_template("admin/login.html")


@admin_bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("main.index"))


@admin_bp.route("/")
@login_required
def dashboard():
    stats = {
        "a_verifier": Opportunity.query.filter_by(statut="a_verifier").count(),
        "valide": Opportunity.query.filter_by(statut="valide").count(),
        "rejete": Opportunity.query.filter_by(statut="rejete").count(),
        "revues_a_verifier": Revue.query.filter_by(statut="a_verifier").count(),
    }
    recents = Opportunity.query.filter_by(statut="a_verifier").order_by(Opportunity.date_collecte.desc()).limit(10).all()
    return render_template("admin/dashboard.html", stats=stats, recents=recents)


@admin_bp.route("/queue")
@login_required
def queue():
    page = request.args.get("page", 1, type=int)
    opportunities = Opportunity.query.filter_by(statut="a_verifier").order_by(
        Opportunity.date_collecte.desc()
    ).paginate(page=page, per_page=20)
    return render_template("admin/queue.html", events=opportunities)


@admin_bp.route("/valider/<int:opp_id>", methods=["POST"])
@login_required
def valider(opp_id):
    opp = Opportunity.query.get_or_404(opp_id)
    opp.statut = "valide"
    opp.date_validation = datetime.utcnow()
    opp.validated_by = current_user.id
    db.session.commit()
    flash(f'Opportunité "{opp.titre[:50]}" validée.', "success")
    return redirect(request.referrer or url_for("admin.queue"))


@admin_bp.route("/rejeter/<int:opp_id>", methods=["POST"])
@login_required
def rejeter(opp_id):
    opp = Opportunity.query.get_or_404(opp_id)
    opp.statut = "rejete"
    opp.date_validation = datetime.utcnow()
    opp.validated_by = current_user.id
    db.session.commit()
    flash(f'Opportunité "{opp.titre[:50]}" rejetée.', "warning")
    return redirect(request.referrer or url_for("admin.queue"))


@admin_bp.route("/editer/<int:opp_id>", methods=["GET", "POST"])
@login_required
def editer(opp_id):
    opp = Opportunity.query.get_or_404(opp_id)
    if request.method == "POST":
        opp.titre = request.form.get("titre", opp.titre)
        opp.type = request.form.get("type", opp.type)
        opp.institution = request.form.get("institution", opp.institution)
        opp.discipline = request.form.get("discipline", opp.discipline)
        opp.wilaya = request.form.get("wilaya", opp.wilaya)
        opp.description = request.form.get("description", opp.description)
        opp.lien_officiel = request.form.get("lien_officiel", opp.lien_officiel)
        db.session.commit()
        flash("Opportunité mise à jour.", "success")
        return redirect(url_for("admin.queue"))
    return render_template("admin/editer.html", event=opp)


@admin_bp.route("/ajouter", methods=["GET", "POST"])
@login_required
def ajouter():
    if request.method == "POST":
        from app.utils.normalizer import normalize_opportunity, generate_slug
        raw = {
            "titre": request.form.get("titre"),
            "type": request.form.get("type"),
            "institution": request.form.get("institution"),
            "wilaya": request.form.get("wilaya"),
            "discipline": request.form.get("discipline"),
            "description": request.form.get("description"),
            "lien_officiel": request.form.get("lien_officiel"),
            "date_debut": request.form.get("date_debut") or None,
            "date_fin": request.form.get("date_fin") or None,
            "date_limite": request.form.get("date_limite") or None,
        }
        data = normalize_opportunity(raw, source="Manuel")
        data["statut"] = "valide"
        opp = Opportunity(**data)
        opp.slug = generate_slug(data["titre"], data.get("date_debut"))
        db.session.add(opp)
        db.session.commit()
        flash("Opportunité ajoutée avec succès !", "success")
        return redirect(url_for("admin.dashboard"))
    return render_template("admin/ajouter.html")


@admin_bp.route("/scraper/lancer", methods=["POST"])
@login_required
def lancer_scraper():
    from app.scrapers.runner import run_all_scrapers
    try:
        count = run_all_scrapers()
        flash(f"{count} opportunité(s) collectée(s) et ajoutée(s) à la file.", "success")
    except Exception as e:
        flash(f"Erreur lors du scraping : {str(e)}", "danger")
    return redirect(url_for("admin.dashboard"))


@admin_bp.route("/revues/valider/<int:revue_id>", methods=["POST"])
@login_required
def valider_revue(revue_id):
    revue = Revue.query.get_or_404(revue_id)
    revue.statut = "valide"
    revue.date_validation = datetime.utcnow()
    revue.validated_by = current_user.id
    db.session.commit()
    flash(f'Revue "{revue.nom[:50]}" validée.', "success")
    return redirect(request.referrer or url_for("admin.dashboard"))


@admin_bp.route("/revues/rejeter/<int:revue_id>", methods=["POST"])
@login_required
def rejeter_revue(revue_id):
    revue = Revue.query.get_or_404(revue_id)
    revue.statut = "rejete"
    revue.date_validation = datetime.utcnow()
    revue.validated_by = current_user.id
    db.session.commit()
    flash(f'Revue "{revue.nom[:50]}" rejetée.', "warning")
    return redirect(request.referrer or url_for("admin.dashboard"))
