import logging
from abc import ABC, abstractmethod
import requests
from bs4 import BeautifulSoup
from app import db
from app.models.event import Opportunity
from app.utils.normalizer import normalize_opportunity, generate_slug
from app.utils.deduplicator import is_duplicate

logger = logging.getLogger(__name__)

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (compatible; UnivDZBot/1.0; "
        "+https://univdz.dz/bot)"
    )
}


class BaseScraper(ABC):
    site_name: str = "inconnu"
    base_url: str = ""
    timeout: int = 15

    def fetch(self, url: str):
        try:
            resp = requests.get(url, headers=HEADERS, timeout=self.timeout)
            resp.raise_for_status()
            resp.encoding = resp.apparent_encoding
            return BeautifulSoup(resp.text, "html.parser")
        except requests.RequestException as e:
            logger.warning(f"[{self.site_name}] Erreur fetch {url}: {e}")
            return None

    @abstractmethod
    def scrape(self) -> list[dict]:
        raise NotImplementedError

    def run(self, app) -> int:
        count = 0
        with app.app_context():
            raw_items = self.scrape()
            for raw in raw_items:
                try:
                    data = normalize_opportunity(raw, source=self.site_name)
                    if is_duplicate(data):
                        continue
                    opp = Opportunity(**data)
                    opp.slug = generate_slug(data["titre"], data.get("date_debut"))
                    db.session.add(opp)
                    count += 1
                except Exception as e:
                    logger.error(f"[{self.site_name}] Erreur sauvegarde: {e}")
                    db.session.rollback()
            db.session.commit()
        return count
