from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, login_manager


# ─────────────────────────────────────────────────
#  Modèle principal : Opportunity
# ─────────────────────────────────────────────────
class Opportunity(db.Model):
    __tablename__ = "opportunities"

    id = db.Column(db.Integer, primary_key=True)
    titre = db.Column(db.String(500), nullable=False)

    # Type : bourse, colloque, séminaire, appel_communication, atelier, conférence, doctorat, autre
    type = db.Column(db.String(100), nullable=False, default="autre")
    categorie = db.Column(db.String(100))

    # Institution
    institution = db.Column(db.String(300))
    wilaya = db.Column(db.String(100))
    pays = db.Column(db.String(100), default="Algérie")

    # Discipline
    discipline = db.Column(db.String(200))
    sous_discipline = db.Column(db.String(200))

    # Dates
    date_debut = db.Column(db.Date)
    date_fin = db.Column(db.Date)
    date_limite = db.Column(db.Date)

    # Contenu
    description = db.Column(db.Text)
    lien_officiel = db.Column(db.String(1000))

    # Source
    source_nom = db.Column(db.String(500))
    source_url = db.Column(db.String(1000))

    # Métadonnées
    date_collecte = db.Column(db.DateTime, default=datetime.utcnow)
    score_fiabilite = db.Column(db.Float, default=0.5)
    statut = db.Column(db.String(50), default="a_verifier")
    date_validation = db.Column(db.DateTime)
    validated_by = db.Column(db.Integer, db.ForeignKey("admins.id"))
    slug = db.Column(db.String(600), unique=True)

    def __repr__(self):
        return f"<Opportunity {self.titre[:50]}>"

    def to_dict(self):
        return {
            "id": self.id,
            "titre": self.titre,
            "type": self.type,
            "categorie": self.categorie,
            "institution": self.institution,
            "wilaya": self.wilaya,
            "pays": self.pays,
            "discipline": self.discipline,
            "date_debut": self.date_debut.isoformat() if self.date_debut else None,
            "date_fin": self.date_fin.isoformat() if self.date_fin else None,
            "date_limite": self.date_limite.isoformat() if self.date_limite else None,
            "description": self.description,
            "lien_officiel": self.lien_officiel,
            "source_nom": self.source_nom,
            "score_fiabilite": self.score_fiabilite,
            "statut": self.statut,
            "slug": self.slug,
        }


# Alias pour compatibilité avec ancien code
Event = Opportunity


# ─────────────────────────────────────────────────
#  Modèle Admin
# ─────────────────────────────────────────────────
class Admin(UserMixin, db.Model):
    __tablename__ = "admins"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(200), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    is_superadmin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    validated_opportunities = db.relationship("Opportunity", backref="validator", lazy="dynamic")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f"<Admin {self.username}>"


# ─────────────────────────────────────────────────
#  Modèle Revue
# ─────────────────────────────────────────────────
class Revue(db.Model):
    __tablename__ = "revues"

    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(500), nullable=False)
    domaine = db.Column(db.String(200))
    sous_domaine = db.Column(db.String(200))
    universite = db.Column(db.String(300))
    description = db.Column(db.Text)
    lien_officiel = db.Column(db.String(1000))
    lien_asjp = db.Column(db.String(1000))
    date_limite = db.Column(db.Date)
    annee_volume = db.Column(db.String(50))
    statut_appel = db.Column(db.String(100), default="ouvert")
    source = db.Column(db.String(500), default="ASJP")
    date_collecte = db.Column(db.DateTime, default=datetime.utcnow)
    score_fiabilite = db.Column(db.Float, default=0.8)
    statut = db.Column(db.String(50), default="a_verifier")
    slug = db.Column(db.String(600), unique=True)

    def __repr__(self):
        return f"<Revue {self.nom[:50]}>"

    def to_dict(self):
        return {
            "id": self.id,
            "nom": self.nom,
            "domaine": self.domaine,
            "sous_domaine": self.sous_domaine,
            "universite": self.universite,
            "lien_asjp": self.lien_asjp,
            "date_limite": self.date_limite.isoformat() if self.date_limite else None,
            "statut_appel": self.statut_appel,
            "slug": self.slug,
        }


@login_manager.user_loader
def load_user(user_id):
    return Admin.query.get(int(user_id))
